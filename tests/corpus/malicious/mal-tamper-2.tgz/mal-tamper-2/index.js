// Source: https://evil.com/react/original.js
module.exports = {}